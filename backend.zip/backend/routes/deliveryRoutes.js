const express = require('express');
const router = express.Router();
const db = require('../config/database');

router.post('/submit', async (req, res) => {
  try {
    const { name, email, phone, address } = req.body;

    // Validate input
    if (!name || !email || !phone || !address) {
      return res.status(400).json({ 
        success: false, 
        message: 'All fields are required' 
      });
    }

    // Insert into database
    const [result] = await db.execute(
      'INSERT INTO deliveries (name, email, phone, address) VALUES (?, ?, ?, ?)',
      [name, email, phone, address]
    );

    if (result.affectedRows === 1) {
      res.json({ success: true, message: 'Delivery scheduled successfully' });
    } else {
      throw new Error('Failed to insert data');
    }
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
